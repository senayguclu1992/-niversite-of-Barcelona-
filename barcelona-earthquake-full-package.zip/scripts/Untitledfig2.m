figure 
subplot(3,1,2);

plot(tvar,signal(p:q,2)),ylabel('m/s');ylim ([-MXT,MXT]);set(gca,'xtick',x);%xlim([45,410])
title ('earthquake-st3 comp2'); 
clc
figure
subplot(3,1,2);

plot(tvar,signal(p:q,2)),ylabel('m/s');ylim ([-MXT,MXT]);set(gca,'xtick',x);%xlim([45,410])
title ('earthquake-st3 comp2'); 
figure 
subplot(3,1,2);

plot(tvar,signal(p:q,2)),ylabel('m/s');ylim ([-MXT,MXT]);set(gca,'xtick',x);%xlim([45,410])
title ('earthquake-st3 comp2'); 

